import { Link, Route, Routes, useLocation } from "react-router-dom";
import Home from "./routes/Home";
import Play from "./routes/Play";
import Leaderboard from "./routes/Leaderboard";
import Settings from "./routes/Settings";

function TopBar() {
  const loc = useLocation();
  return (
    <header className="topbar">
      <div className="brand">
        <span className="logo">☕</span>
        <span>Neon Tap</span>
      </div>
      <div className="path">{loc.pathname}</div>
    </header>
  );
}

function Tabs() {
  return (
    <nav className="tabs">
      <Link to="/">Home</Link>
      <Link to="/play">Play</Link>
      <Link to="/leaderboard">Ranks</Link>
      <Link to="/settings">Settings</Link>
    </nav>
  );
}

export default function App() {
  return (
    <div className="appShell">
      <TopBar />
      <main className="content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/play" element={<Play />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
      <Tabs />
    </div>
  );
}

type Run = { score: number; dateISO: string };
const LS_RUNS = "neontap_runs";

function loadRuns(): Run[] {
  try { return JSON.parse(localStorage.getItem(LS_RUNS) || "[]"); } catch { return []; }
}

export default function Leaderboard() {
  const runs = loadRuns().sort((a, b) => b.score - a.score);

  return (
    <div className="card">
      <h2 className="h2">Leaderboard</h2>
      <p className="muted">Top recent runs (stored locally).</p>

      {runs.length === 0 ? (
        <div className="empty">No runs yet — go play!</div>
      ) : (
        <div className="list">
          {runs.slice(0, 10).map((r, idx) => (
            <div className="listItem" key={r.dateISO + idx}>
              <div className="rank">#{idx + 1}</div>
              <div className="grow">
                <div className="bold">{r.score} pts</div>
                <div className="muted small">{new Date(r.dateISO).toLocaleString()}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="card">
      <h1 className="h1">Neon Tap</h1>
      <p className="muted">
        Tap fast, beat the timer, and level up. This is a sample repo to test KopiCode’s web → native pipeline.
      </p>

      <div className="statsRow">
        <div className="stat">
          <div className="statLabel">Mode</div>
          <div className="statValue">30s Sprint</div>
        </div>
        <div className="stat">
          <div className="statLabel">Goal</div>
          <div className="statValue">Score 150+</div>
        </div>
      </div>

      <Link className="btnPrimary" to="/play">Start Game</Link>

      <div className="hint">
        Tip: This app includes PWA manifest + service worker + routing, so your analyzer should mark many steps ✅.
      </div>
    </div>
  );
}

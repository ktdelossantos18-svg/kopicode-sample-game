import { useEffect, useMemo, useRef, useState } from "react";

type Run = { score: number; dateISO: string };
const LS_RUNS = "neontap_runs";
const LS_SETTINGS = "neontap_settings";

function loadRuns(): Run[] {
  try { return JSON.parse(localStorage.getItem(LS_RUNS) || "[]"); } catch { return []; }
}
function saveRuns(runs: Run[]) {
  localStorage.setItem(LS_RUNS, JSON.stringify(runs.slice(0, 20)));
}
function loadSettings(): { sound: boolean; vibration: boolean } {
  try { return JSON.parse(localStorage.getItem(LS_SETTINGS) || '{"sound":true,"vibration":true}'); }
  catch { return { sound: true, vibration: true }; }
}

export default function Play() {
  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);
  const [running, setRunning] = useState(false);
  const [level, setLevel] = useState(1);
  const settings = useMemo(() => loadSettings(), []);
  const timerRef = useRef<number | null>(null);

  const target = 30 + level * 20;

  useEffect(() => {
    if (!running) return;
    timerRef.current = window.setInterval(() => {
      setTimeLeft((t) => t - 1);
    }, 1000);

    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (!running) return;
    if (timeLeft <= 0) {
      setRunning(false);
      const runs = loadRuns();
      saveRuns([{ score, dateISO: new Date().toISOString() }, ...runs]);
    }
  }, [timeLeft, running, score]);

  function start() {
    setScore(0);
    setTimeLeft(30);
    setRunning(true);
  }

  function tap() {
    if (!running) return;
    setScore((s) => s + 1);

    if (settings.vibration && "vibrate" in navigator) {
      // small haptic-like vibration on supported devices
      // @ts-ignore
      navigator.vibrate(10);
    }
  }

  useEffect(() => {
    // level up if score target hit before time ends
    if (!running) return;
    if (score >= target) {
      setLevel((l) => l + 1);
      setTimeLeft((t) => Math.min(45, t + 5));
    }
  }, [score, target, running]);

  return (
    <div className="card">
      <div className="rowBetween">
        <div>
          <div className="pill">Level {level}</div>
          <div className="muted">Target: {target}</div>
        </div>
        <div className="timer">{timeLeft}s</div>
      </div>

      <div className="scoreBox">
        <div className="scoreLabel">Score</div>
        <div className="scoreValue">{score}</div>
      </div>

      {!running ? (
        <button className="btnPrimary" onClick={start}>
          {timeLeft <= 0 ? "Play Again" : "Start"}
        </button>
      ) : (
        <button className="tapBtn" onClick={tap}>
          TAP!
        </button>
      )}

      <div className="muted small">
        This page intentionally uses touch-first UI to prove mobile readiness.
      </div>
    </div>
  );
}

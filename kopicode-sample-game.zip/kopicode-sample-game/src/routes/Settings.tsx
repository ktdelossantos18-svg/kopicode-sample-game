import { useEffect, useState } from "react";

const LS_SETTINGS = "neontap_settings";

export default function Settings() {
  const [sound, setSound] = useState(true);
  const [vibration, setVibration] = useState(true);

  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem(LS_SETTINGS) || '{"sound":true,"vibration":true}');
      setSound(!!s.sound);
      setVibration(!!s.vibration);
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem(LS_SETTINGS, JSON.stringify({ sound, vibration }));
  }, [sound, vibration]);

  return (
    <div className="card">
      <h2 className="h2">Settings</h2>
      <p className="muted">These mimic “native-ish” toggles you might expose in a wrapper app.</p>

      <label className="toggleRow">
        <span>Sound effects (placeholder)</span>
        <input type="checkbox" checked={sound} onChange={(e) => setSound(e.target.checked)} />
      </label>

      <label className="toggleRow">
        <span>Vibration on tap (if supported)</span>
        <input type="checkbox" checked={vibration} onChange={(e) => setVibration(e.target.checked)} />
      </label>

      <div className="hint">
        For iOS App Store approval, wrappers should add real native value like offline screen, share sheet, file handling, etc.
      </div>
    </div>
  );
}
